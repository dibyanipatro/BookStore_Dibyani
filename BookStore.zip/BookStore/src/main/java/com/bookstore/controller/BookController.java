package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.model.Category;
import com.bookstore.service.BookService;
import com.bookstore.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public String getAllBooks(Model model){
        List<Book> books = bookService.findAllBooks();
        model.addAttribute("books", books);
        return "books";
    }
    @GetMapping("/new")
    public String createBookForm(Model model){
        List<Category> categories = categoryService.findAllCategories();
        model.addAttribute("book", new Book());
        model.addAttribute("categories", categories);
        return "create_book";
    }

    @PostMapping
    public String saveBook(@ModelAttribute("book") Book book){
        bookService.saveBook(book);
        return "redirect:/books";
    }
    @GetMapping("edit/{id}")
    private String editBookForm(@PathVariable Long id, Model model){
        Book book = bookService.findBookById(id);
        List<Category> categories = categoryService.findAllCategories();
        model.addAttribute("book", book);
        model.addAttribute("categories", categories);
        return "edit_book";
    }
    @PostMapping("/{id}")
    public String updateBook(@PathVariable Long id, @ModelAttribute("book") Book book){
        Book existingBook = bookService.findBookById(id);
        existingBook.setTitle(book.getTitle());
        existingBook.setAuthor(book.getAuthor());
        existingBook.setPrice(book.getPrice());
        existingBook.setCategory(book.getCategory());
        existingBook.setStock(book.getStock());
        bookService.saveBook(existingBook);
        return "redirect:/books";
    }

    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id){
        bookService.deleteBook(id);
        return "redirect:/books";
    }

    @GetMapping("/books")
    public String showBooksPage(Model model) {
        // Retrieve the list of books from the database
        List<Book> books = bookService.findAllBooks();

        // Add the list of books to the model
        model.addAttribute("books", books);

        // Return the view name
        return "books"; // maps to books.jsp
    }

    @GetMapping("/create-book")
    public String showCreateBookPage(Model model) {
        // Create a new empty Book object
        Book book = new Book();

        // Add the empty Book object to the model
        model.addAttribute("book", book);

        // Return the view name
        return "create_book"; // maps to create_book.jsp
    }

    @PostMapping("/create-book")
    public String createBook(@ModelAttribute("book") Book book) {
        // Save the new book to the database
        bookService.saveBook(book);

        // Redirect to the list of books
        return "redirect:/books";
    }






}
