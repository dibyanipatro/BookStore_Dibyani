package com.bookstore.controller;

import com.bookstore.model.Category;
import com.bookstore.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public String getAllCategories(Model model){
        List<Category> categories = categoryService.findAllCategories();
        model.addAttribute("categories", categories);
        return "categories";
    }
    @GetMapping("/new")
    public String createCategoryForm(Model model){
        model.addAttribute("category", new Category());
        return "create_category";
    }

    @PostMapping
    public String saveCategory(@ModelAttribute("category") Category category){
        categoryService.saveCategory(category);
    return "redirect:/categories";
    }

    @GetMapping("/edit/{id}")
    public String editCategoryForm(@PathVariable Long id, Model model){
        Category category = categoryService.findCategoryById(id);
        model.addAttribute("category", category);
        return "edit_category";
    }

    @PostMapping("/{id}")
    public String updateCategory(@PathVariable Long id, @ModelAttribute("category") Category category){
        Category existingCategory = categoryService.findCategoryById(id);
        existingCategory.setName(category.getName());
        categoryService.saveCategory(existingCategory);
        return "redirect:/categories";
    }
    @GetMapping("/categories")
    public String showCategoriesPage(Model model) {
        // Get all categories from the service
        List<Category> categories = categoryService.findAllCategories();

        // Add categories to the model
        model.addAttribute("categories", categories);

        // Return the view name
        return "categories"; // maps to categories.jsp
    }

    @GetMapping("/create-category")
    public String showCreateCategoryPage(Model model)  {
        // Add an empty Category object to the model for the form
        model.addAttribute("category", new Category());

        // Return the view name
        return "create_category"; // maps to create_category.jsp
    }
}
